import tkinter as tk
from tkinter import ttk, messagebox
import pyodbc

class TransportApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Transport Management System")
        self.root.geometry("800x600")
        
        # Database connection
        self.conn = None
        self.cursor = None
        
        # Initialize UI
        self.create_widgets()
        
        # Connect to database on startup
        self.connect_to_database()
    
    def connect_to_database(self):
        """Connect to SQL Server database"""
        try:
            # Replace these with your actual SQL Server connection details
            server = 'YOUR_SERVER_NAME'  # e.g., 'localhost\SQLEXPRESS'
            database = 'TransportDB'
            username = 'YOUR_USERNAME'
            password = 'YOUR_PASSWORD'
            
            # Connection string
            conn_str = (
                f'DRIVER={{SQL Server}};'
                f'SERVER={server};'
                f'DATABASE={database};'
                f'UID={username};'
                f'PWD={password}'
            )
            
            self.conn = pyodbc.connect(conn_str)
            self.cursor = self.conn.cursor()
            messagebox.showinfo("Success", "Connected to the database successfully!")
            
        except Exception as e:
            messagebox.showerror("Database Error", f"Could not connect to database: {str(e)}")
    
    def create_widgets(self):
        """Create the main GUI elements"""
        # Create notebook for tabs
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Create tabs
        self.vehicles_tab = ttk.Frame(self.notebook)
        self.routes_tab = ttk.Frame(self.notebook)
        self.drivers_tab = ttk.Frame(self.notebook)
        self.bookings_tab = ttk.Frame(self.notebook)
        
        self.notebook.add(self.vehicles_tab, text="Vehicles")
        self.notebook.add(self.routes_tab, text="Routes")
        self.notebook.add(self.drivers_tab, text="Drivers")
        self.notebook.add(self.bookings_tab, text="Bookings")
        
        # Set up each tab
        self.setup_vehicles_tab()
        self.setup_routes_tab()
        self.setup_drivers_tab()
        self.setup_bookings_tab()
        
        # Add a status bar
        self.status_bar = tk.Label(
            self.root, 
            text="Ready", 
            bd=1, 
            relief=tk.SUNKEN, 
            anchor=tk.W
        )
        self.status_bar.pack(side=tk.BOTTOM, fill=tk.X)
    
    def setup_vehicles_tab(self):
        """Set up the Vehicles tab"""
        # Frame for vehicle list
        list_frame = ttk.LabelFrame(self.vehicles_tab, text="Vehicle List")
        list_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Create treeview for vehicle list
        columns = ("ID", "Type", "Registration", "Capacity", "Status")
        self.vehicle_tree = ttk.Treeview(list_frame, columns=columns, show="headings")
        
        # Set column headings
        for col in columns:
            self.vehicle_tree.heading(col, text=col)
            self.vehicle_tree.column(col, width=100)
        
        self.vehicle_tree.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # Add scrollbar
        scrollbar = ttk.Scrollbar(list_frame, orient=tk.VERTICAL, command=self.vehicle_tree.yview)
        self.vehicle_tree.configure(yscroll=scrollbar.set)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # Frame for vehicle actions
        actions_frame = ttk.LabelFrame(self.vehicles_tab, text="Vehicle Actions")
        actions_frame.pack(fill=tk.X, padx=10, pady=10)
        
        # Action buttons
        ttk.Button(actions_frame, text="Add Vehicle", command=self.add_vehicle).pack(side=tk.LEFT, padx=5, pady=5)
        ttk.Button(actions_frame, text="Edit Vehicle", command=self.edit_vehicle).pack(side=tk.LEFT, padx=5, pady=5)
        ttk.Button(actions_frame, text="Delete Vehicle", command=self.delete_vehicle).pack(side=tk.LEFT, padx=5, pady=5)
        ttk.Button(actions_frame, text="Refresh", command=self.refresh_vehicles).pack(side=tk.LEFT, padx=5, pady=5)
    
    def setup_routes_tab(self):
        """Set up the Routes tab"""
        # Frame for route list
        list_frame = ttk.LabelFrame(self.routes_tab, text="Route List")
        list_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Create treeview for route list
        columns = ("ID", "Start Location", "End Location", "Distance", "Duration")
        self.route_tree = ttk.Treeview(list_frame, columns=columns, show="headings")
        
        # Set column headings
        for col in columns:
            self.route_tree.heading(col, text=col)
            self.route_tree.column(col, width=100)
        
        self.route_tree.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # Add scrollbar
        scrollbar = ttk.Scrollbar(list_frame, orient=tk.VERTICAL, command=self.route_tree.yview)
        self.route_tree.configure(yscroll=scrollbar.set)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # Frame for route actions
        actions_frame = ttk.LabelFrame(self.routes_tab, text="Route Actions")
        actions_frame.pack(fill=tk.X, padx=10, pady=10)
        
        # Action buttons
        ttk.Button(actions_frame, text="Add Route", command=self.add_route).pack(side=tk.LEFT, padx=5, pady=5)
        ttk.Button(actions_frame, text="Edit Route", command=self.edit_route).pack(side=tk.LEFT, padx=5, pady=5)
        ttk.Button(actions_frame, text="Delete Route", command=self.delete_route).pack(side=tk.LEFT, padx=5, pady=5)
        ttk.Button(actions_frame, text="Refresh", command=self.refresh_routes).pack(side=tk.LEFT, padx=5, pady=5)
    
    def setup_drivers_tab(self):
        """Set up the Drivers tab"""
        # Frame for driver list
        list_frame = ttk.LabelFrame(self.drivers_tab, text="Driver List")
        list_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Create treeview for driver list
        columns = ("ID", "Name", "License", "Phone", "Status")
        self.driver_tree = ttk.Treeview(list_frame, columns=columns, show="headings")
        
        # Set column headings
        for col in columns:
            self.driver_tree.heading(col, text=col)
            self.driver_tree.column(col, width=100)
        
        self.driver_tree.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # Add scrollbar
        scrollbar = ttk.Scrollbar(list_frame, orient=tk.VERTICAL, command=self.driver_tree.yview)
        self.driver_tree.configure(yscroll=scrollbar.set)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # Frame for driver actions
        actions_frame = ttk.LabelFrame(self.drivers_tab, text="Driver Actions")
        actions_frame.pack(fill=tk.X, padx=10, pady=10)
        
        # Action buttons
        ttk.Button(actions_frame, text="Add Driver", command=self.add_driver).pack(side=tk.LEFT, padx=5, pady=5)
        ttk.Button(actions_frame, text="Edit Driver", command=self.edit_driver).pack(side=tk.LEFT, padx=5, pady=5)
        ttk.Button(actions_frame, text="Delete Driver", command=self.delete_driver).pack(side=tk.LEFT, padx=5, pady=5)
        ttk.Button(actions_frame, text="Refresh", command=self.refresh_drivers).pack(side=tk.LEFT, padx=5, pady=5)
    
    def setup_bookings_tab(self):
        """Set up the Bookings tab"""
        # Frame for booking list
        list_frame = ttk.LabelFrame(self.bookings_tab, text="Booking List")
        list_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Create treeview for booking list
        columns = ("ID", "Route", "Vehicle", "Driver", "Date", "Time", "Status")
        self.booking_tree = ttk.Treeview(list_frame, columns=columns, show="headings")
        
        # Set column headings
        for col in columns:
            self.booking_tree.heading(col, text=col)
            self.booking_tree.column(col, width=100)
        
        self.booking_tree.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # Add scrollbar
        scrollbar = ttk.Scrollbar(list_frame, orient=tk.VERTICAL, command=self.booking_tree.yview)
        self.booking_tree.configure(yscroll=scrollbar.set)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # Frame for booking actions
        actions_frame = ttk.LabelFrame(self.bookings_tab, text="Booking Actions")
        actions_frame.pack(fill=tk.X, padx=10, pady=10)
        
        # Action buttons
        ttk.Button(actions_frame, text="Add Booking", command=self.add_booking).pack(side=tk.LEFT, padx=5, pady=5)
        ttk.Button(actions_frame, text="Edit Booking", command=self.edit_booking).pack(side=tk.LEFT, padx=5, pady=5)
        ttk.Button(actions_frame, text="Delete Booking", command=self.delete_booking).pack(side=tk.LEFT, padx=5, pady=5)
        ttk.Button(actions_frame, text="Refresh", command=self.refresh_bookings).pack(side=tk.LEFT, padx=5, pady=5)
    
    # Vehicle methods
    def add_vehicle(self):
        self.open_vehicle_dialog("add")
    
    def edit_vehicle(self):
        selected = self.vehicle_tree.selection()
        if not selected:
            messagebox.showwarning("Warning", "Please select a vehicle to edit")
            return
        self.open_vehicle_dialog("edit", selected[0])
    
    def delete_vehicle(self):
        selected = self.vehicle_tree.selection()
        if not selected:
            messagebox.showwarning("Warning", "Please select a vehicle to delete")
            return
        
        if messagebox.askyesno("Confirm Delete", "Are you sure you want to delete this vehicle?"):
            # Code to delete from database
            messagebox.showinfo("Success", "Vehicle deleted successfully")
    
    def refresh_vehicles(self):
        # Clear current items
        for item in self.vehicle_tree.get_children():
            self.vehicle_tree.delete(item)
        
        # Sample data - would come from database
        sample_data = [
            (1, "Bus", "XYZ123", 50, "Active"),
            (2, "Van", "ABC456", 15, "Active"),
            (3, "Train", "DEF789", 200, "Maintenance")
        ]
        
        for item in sample_data:
            self.vehicle_tree.insert("", tk.END, values=item)
    
    def open_vehicle_dialog(self, mode, item_id=None):
        """Open dialog for adding or editing a vehicle"""
        dialog = tk.Toplevel(self.root)
        dialog.title("Add Vehicle" if mode == "add" else "Edit Vehicle")
        dialog.geometry("400x300")
        dialog.transient(self.root)
        dialog.grab_set()
        
        # Create form
        ttk.Label(dialog, text="Vehicle Type:").grid(row=0, column=0, padx=10, pady=10, sticky=tk.W)
        vehicle_type = ttk.Entry(dialog, width=30)
        vehicle_type.grid(row=0, column=1, padx=10, pady=10)
        
        ttk.Label(dialog, text="Registration:").grid(row=1, column=0, padx=10, pady=10, sticky=tk.W)
        registration = ttk.Entry(dialog, width=30)
        registration.grid(row=1, column=1, padx=10, pady=10)
        
        ttk.Label(dialog, text="Capacity:").grid(row=2, column=0, padx=10, pady=10, sticky=tk.W)
        capacity = ttk.Entry(dialog, width=30)
        capacity.grid(row=2, column=1, padx=10, pady=10)
        
        ttk.Label(dialog, text="Status:").grid(row=3, column=0, padx=10, pady=10, sticky=tk.W)
        status = ttk.Combobox(dialog, values=["Active", "Maintenance", "Out of Service"], width=27)
        status.grid(row=3, column=1, padx=10, pady=10)
        
        # Buttons
        btn_frame = ttk.Frame(dialog)
        btn_frame.grid(row=4, column=0, columnspan=2, pady=20)
        
        ttk.Button(btn_frame, text="Save", command=lambda: self.save_vehicle(
            dialog, mode, vehicle_type.get(), registration.get(), capacity.get(), status.get(), item_id
        )).pack(side=tk.LEFT, padx=10)
        
        ttk.Button(btn_frame, text="Cancel", command=dialog.destroy).pack(side=tk.LEFT, padx=10)
    
    def save_vehicle(self, dialog, mode, vtype, reg, capacity, status, item_id=None):
        # Validate inputs
        if not vtype or not reg or not capacity or not status:
            messagebox.showwarning("Input Error", "All fields are required", parent=dialog)
            return
        
        # Save to database
        # ...
        
        messagebox.showinfo("Success", 
                           f"Vehicle {'added' if mode == 'add' else 'updated'} successfully", 
                           parent=dialog)
        dialog.destroy()
        self.refresh_vehicles()
    
    # Route methods
    def add_route(self):
        # Similar to add_vehicle
        pass
    
    def edit_route(self):
        # Similar to edit_vehicle
        pass
    
    def delete_route(self):
        # Similar to delete_vehicle
        pass
    
    def refresh_routes(self):
        # Similar to refresh_vehicles
        pass
    
    # Driver methods
    def add_driver(self):
        # Similar to add_vehicle
        pass
    
    def edit_driver(self):
        # Similar to edit_vehicle
        pass
    
    def delete_driver(self):
        # Similar to delete_vehicle
        pass
    
    def refresh_drivers(self):
        # Similar to refresh_vehicles
        pass
    
    # Booking methods
    def add_booking(self):
        # Similar to add_vehicle
        pass
    
    def edit_booking(self):
        # Similar to edit_vehicle
        pass
    
    def delete_booking(self):
        # Similar to delete_vehicle
        pass
    
    def refresh_bookings(self):
        # Similar to refresh_vehicles
        pass

if __name__ == "__main__":
    root = tk.Tk()
    app = TransportApp(root)
    root.mainloop()