-- Create the Transport System Database
CREATE DATABASE TransportDB;
GO

USE TransportDB;
GO

-- Create Vehicles table
CREATE TABLE Vehicles (
    VehicleID INT PRIMARY KEY IDENTITY(1,1),
    VehicleType NVARCHAR(50) NOT NULL,
    RegistrationNumber NVARCHAR(20) NOT NULL UNIQUE,
    Capacity INT NOT NULL,
    Status NVARCHAR(20) NOT NULL CHECK (Status IN ('Active', 'Maintenance', 'Out of Service')),
    DateAdded DATETIME DEFAULT GETDATE(),
    LastModified DATETIME DEFAULT GETDATE()
);
GO

-- Create Routes table
CREATE TABLE Routes (
    RouteID INT PRIMARY KEY IDENTITY(1,1),
    StartLocation NVARCHAR(100) NOT NULL,
    EndLocation NVARCHAR(100) NOT NULL,
    Distance DECIMAL(10, 2) NOT NULL, -- in kilometers
    Duration INT NOT NULL, -- in minutes
    Description NVARCHAR(500),
    DateAdded DATETIME DEFAULT GETDATE(),
    LastModified DATETIME DEFAULT GETDATE()
);
GO

-- Create Drivers table
CREATE TABLE Drivers (
    DriverID INT PRIMARY KEY IDENTITY(1,1),
    FirstName NVARCHAR(50) NOT NULL,
    LastName NVARCHAR(50) NOT NULL,
    LicenseNumber NVARCHAR(50) NOT NULL UNIQUE,
    PhoneNumber NVARCHAR(20) NOT NULL,
    Email NVARCHAR(100),
    Status NVARCHAR(20) NOT NULL CHECK (Status IN ('Available', 'On Duty', 'On Leave', 'Terminated')),
    DateHired DATE NOT NULL,
    DateAdded DATETIME DEFAULT GETDATE(),
    LastModified DATETIME DEFAULT GETDATE()
);
GO

-- Create Bookings table
CREATE TABLE Bookings (
    BookingID INT PRIMARY KEY IDENTITY(1,1),
    RouteID INT NOT NULL,
    VehicleID INT NOT NULL,
    DriverID INT NOT NULL,
    BookingDate DATE NOT NULL,
    DepartureTime TIME NOT NULL,
    ArrivalTime TIME,
    Status NVARCHAR(20) NOT NULL CHECK (Status IN ('Scheduled', 'In Progress', 'Completed', 'Cancelled')),
    PassengerCount INT,
    Notes NVARCHAR(500),
    DateAdded DATETIME DEFAULT GETDATE(),
    LastModified DATETIME DEFAULT GETDATE(),
    FOREIGN KEY (RouteID) REFERENCES Routes(RouteID),
    FOREIGN KEY (VehicleID) REFERENCES Vehicles(VehicleID),
    FOREIGN KEY (DriverID) REFERENCES Drivers(DriverID)
);
GO

-- Create Passengers table (for extended functionality)
CREATE TABLE Passengers (
    PassengerID INT PRIMARY KEY IDENTITY(1,1),
    FirstName NVARCHAR(50) NOT NULL,
    LastName NVARCHAR(50) NOT NULL,
    PhoneNumber NVARCHAR(20),
    Email NVARCHAR(100),
    DateAdded DATETIME DEFAULT GETDATE(),
    LastModified DATETIME DEFAULT GETDATE()
);
GO

-- Create BookingPassengers junction table (many-to-many relationship)
CREATE TABLE BookingPassengers (
    BookingID INT NOT NULL,
    PassengerID INT NOT NULL,
    DateAdded DATETIME DEFAULT GETDATE(),
    PRIMARY KEY (BookingID, PassengerID),
    FOREIGN KEY (BookingID) REFERENCES Bookings(BookingID),
    FOREIGN KEY (PassengerID) REFERENCES Passengers(PassengerID)
);
GO

-- Create Maintenance Records table
CREATE TABLE MaintenanceRecords (
    MaintenanceID INT PRIMARY KEY IDENTITY(1,1),
    VehicleID INT NOT NULL,
    MaintenanceType NVARCHAR(50) NOT NULL,
    MaintenanceDate DATE NOT NULL,
    Description NVARCHAR(500),
    Cost DECIMAL(10, 2),
    TechnicianName NVARCHAR(100),
    DateAdded DATETIME DEFAULT GETDATE(),
    LastModified DATETIME DEFAULT GETDATE(),
    FOREIGN KEY (VehicleID) REFERENCES Vehicles(VehicleID)
);
GO

-- Create sample stored procedures

-- Procedure to get all available vehicles
CREATE PROCEDURE GetAvailableVehicles
AS
BEGIN
    SELECT * FROM Vehicles WHERE Status = 'Active'
    ORDER BY VehicleType, RegistrationNumber;
END
GO

-- Procedure to get all available drivers
CREATE PROCEDURE GetAvailableDrivers
AS
BEGIN
    SELECT * FROM Drivers WHERE Status = 'Available'
    ORDER BY LastName, FirstName;
END
GO

-- Procedure to create a new booking
CREATE PROCEDURE CreateBooking
    @RouteID INT,
    @VehicleID INT,
    @DriverID INT,
    @BookingDate DATE,
    @DepartureTime TIME,
    @Status NVARCHAR(20),
    @PassengerCount INT = NULL,
    @Notes NVARCHAR(500) = NULL
AS
BEGIN
    INSERT INTO Bookings (
        RouteID, 
        VehicleID, 
        DriverID, 
        BookingDate, 
        DepartureTime, 
        Status, 
        PassengerCount, 
        Notes
    )
    VALUES (
        @RouteID,
        @VehicleID,
        @DriverID,
        @BookingDate,
        @DepartureTime,
        @Status,
        @PassengerCount,
        @Notes
    );
    
    -- Return the ID of the newly created booking
    SELECT SCOPE_IDENTITY() AS BookingID;
END
GO

-- Insert sample data for testing

-- Sample Vehicles
INSERT INTO Vehicles (VehicleType, RegistrationNumber, Capacity, Status)
VALUES 
    ('Bus', 'ABC123', 50, 'Active'),
    ('Van', 'XYZ456', 15, 'Active'),
    ('Bus', 'DEF789', 45, 'Maintenance'),
    ('Minibus', 'GHI101', 25, 'Active'),
    ('Train', 'JKL202', 200, 'Active');
GO

-- Sample Routes
INSERT INTO Routes (StartLocation, EndLocation, Distance, Duration, Description)
VALUES 
    ('City Center', 'Airport', 15.5, 30, 'Direct route to the airport'),
    ('North Station', 'South Station', 8.2, 20, 'Cross-city connection'),
    ('West Terminal', 'East Terminal', 12.0, 25, 'East-west route'),
    ('Downtown', 'Suburb', 10.3, 22, 'Commuter route'),
    ('Central Station', 'Business Park', 5.7, 15, 'Business express');
GO

-- Sample Drivers
INSERT INTO Drivers (FirstName, LastName, LicenseNumber, PhoneNumber, Email, Status, DateHired)
VALUES 
    ('John', 'Smith', 'DL12345', '555-1234', 'john.smith@email.com', 'Available', '2022-01-15'),
    ('Emily', 'Johnson', 'DL67890', '555-5678', 'emily.j@email.com', 'On Duty', '2021-11-03'),
    ('Michael', 'Brown', 'DL24680', '555-9012', 'michael.b@email.com', 'Available', '2023-03-22'),
    ('Sarah', 'Davis', 'DL13579', '555-3456', 'sarah.d@email.com', 'On Leave', '2022-07-10'),
    ('David', 'Wilson', 'DL97531', '555-7890', 'david.w@email.com', 'Available', '2023-01-05');
GO

-- Sample Bookings
INSERT INTO Bookings (RouteID, VehicleID, DriverID, BookingDate, DepartureTime, Status, PassengerCount, Notes)
VALUES 
    (1, 1, 1, '2025-03-15', '08:00:00', 'Scheduled', 35, 'Morning airport shuttle'),
    (2, 4, 3, '2025-03-15', '09:30:00', 'Scheduled', 20, 'Regular route'),
    (3, 2, 5, '2025-03-16', '14:15:00', 'Scheduled', 12, 'Afternoon service'),
    (4, 1, 2, '2025-03-17', '17:45:00', 'Scheduled', 40, 'Evening commuter service'),
    (5, 4, 1, '2025-03-18', '07:30:00', 'Scheduled', 18, 'Business express');
GO